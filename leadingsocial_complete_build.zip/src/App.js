import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to LeadingSocial</h1>
      <p>Your AI-powered marketing assistant</p>
    </div>
  );
}

export default App;
